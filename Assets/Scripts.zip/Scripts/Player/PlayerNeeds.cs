﻿using UnityEngine;
using UnityEngine.UI;

namespace Orivilon.Player
{
    /// <summary>
    /// Spravuje základní životní potřeby hráče: zdraví, hlad a žízeň.
    /// Hlad a žízeň postupně klesají (rychleji při sprintu).
    /// Pokud klesnou na nulu, začne ubývat zdraví.
    /// Pokud jsou obě hodnoty nad prahem healThreshold, zdraví se regeneruje.
    /// UI bary se plynule aktualizují pomocí Lerp každý snímek.
    /// </summary>
    public class PlayerNeeds : MonoBehaviour
    {
        /// <summary>Maximální hodnota zdraví.</summary>
        [Header("Max Values")]
        public float maxHealth = 100f;

        /// <summary>Maximální hodnota hladu.</summary>
        public float maxFood = 100f;

        /// <summary>Maximální hodnota žízně.</summary>
        public float maxWater = 100f;

        /// <summary>Aktuální hodnota zdraví (0–maxHealth).</summary>
        [Header("Current Values")]
        public float health = 100f;

        /// <summary>Aktuální hodnota hladu (0–maxFood).</summary>
        public float food = 100f;

        /// <summary>Aktuální hodnota žízně (0–maxWater).</summary>
        public float water = 100f;

        /// <summary>Rychlost ubývání hladu za sekundu při normálním pohybu.</summary>
        [Header("Drain Settings")]
        public float foodDrainPerSecond = 0.5f;

        /// <summary>Rychlost ubývání žízně za sekundu při normálním pohybu.</summary>
        public float waterDrainPerSecond = 0.7f;

        /// <summary>Násobitel rychlosti ubývání při sprintu (výchozí 2 = dvojnásobné tempo).</summary>
        public float runningMultiplier = 2f;

        /// <summary>Rychlost regenerace zdraví za sekundu (platí jen nad prahem healThreshold).</summary>
        [Header("Health Regeneration")]
        public float healPerSecond = 2f;

        /// <summary>Minimální hodnota hladu I žízně nutná pro regeneraci zdraví.</summary>
        public float healThreshold = 50f;

        /// <summary>Reference na FirstPersonController pro detekci sprintu.</summary>
        [Header("Reference")]
        public FirstPersonController playerMovement;

        /// <summary>Image komponenta baru zdraví (fillAmount = health/maxHealth).</summary>
        [Header("UI Bars")]
        public Image healthBar;

        /// <summary>Image komponenta baru hladu (fillAmount = food/maxFood).</summary>
        public Image foodBar;

        /// <summary>Image komponenta baru žízně (fillAmount = water/maxWater).</summary>
        public Image waterBar;

        /// <summary>
        /// Každý snímek aktualizuje potřeby, zdraví a UI.
        /// </summary>
        private void Update()
        {
            HandleNeedsDrain();
            HandleHealing();
            UpdateUI();
        }

        /// <summary>
        /// Snižuje hlad a žízeň každý snímek.
        /// Při sprintu se násobí hodnotou runningMultiplier.
        /// Pokud hlad nebo žízeň dosáhnou nuly, ubývá zdraví rychlostí 5/s.
        /// Všechny hodnoty jsou omezeny na rozsah 0–maximum.
        /// </summary>
        private void HandleNeedsDrain()
        {
            bool isRunning = playerMovement != null && playerMovement.isSprinting;

            float multiplier = isRunning ? runningMultiplier : 1f;

            food -= foodDrainPerSecond * multiplier * Time.deltaTime;
            water -= waterDrainPerSecond * multiplier * Time.deltaTime;

            food = Mathf.Clamp(food, 0, maxFood);
            water = Mathf.Clamp(water, 0, maxWater);

            if (food <= 0 || water <= 0)
            {
                health -= 5f * Time.deltaTime;
            }

            health = Mathf.Clamp(health, 0, maxHealth);
        }

        /// <summary>
        /// Regeneruje zdraví pokud hlad i žízeň přesahují healThreshold.
        /// Regenerace se zastaví při dosažení maxHealth.
        /// </summary>
        private void HandleHealing()
        {
            if (food >= healThreshold && water >= healThreshold)
            {
                if (health < maxHealth)
                {
                    health += healPerSecond * Time.deltaTime;
                    health = Mathf.Clamp(health, 0, maxHealth);
                }
            }
        }

        /// <summary>
        /// Přidá zadané množství hladu hráči (omezeně na maxFood).
        /// </summary>
        /// <param name="amount">Množství hladu k přidání.</param>
        public void AddFood(float amount)
        {
            food += amount;
            food = Mathf.Clamp(food, 0, maxFood);
        }

        /// <summary>
        /// Přidá zadané množství žízně hráči (omezeně na maxWater).
        /// </summary>
        /// <param name="amount">Množství žízně k přidání.</param>
        public void AddWater(float amount)
        {
            water += amount;
            water = Mathf.Clamp(water, 0, maxWater);
        }

        /// <summary>
        /// Způsobí hráči poškození snížením zdraví (omezeně na 0).
        /// </summary>
        /// <param name="amount">Množství poškození.</param>
        public void Damage(float amount)
        {
            health -= amount;
            health = Mathf.Clamp(health, 0, maxHealth);
        }

        /// <summary>
        /// Plynule aktualizuje fillAmount všech tří UI barů pomocí Lerp.
        /// Rychlost přechodu je 5× za sekundu.
        /// </summary>
        private void UpdateUI()
        {
            if (healthBar != null)
                healthBar.fillAmount = Mathf.Lerp(healthBar.fillAmount, health / maxHealth, Time.deltaTime * 5f);

            if (foodBar != null)
                foodBar.fillAmount = Mathf.Lerp(foodBar.fillAmount, food / maxFood, Time.deltaTime * 5f);

            if (waterBar != null)
                waterBar.fillAmount = Mathf.Lerp(waterBar.fillAmount, water / maxWater, Time.deltaTime * 5f);
        }
    }
}