using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Orivilon.Core
{
    /// <summary>
    /// Pr�zdn� MonoBehaviour slou��c� jako hostitelsk� objekt pro coroutiny spravovan� p�es CoroutineHelper.
    /// Vytv��� se automaticky jako nov� GameObject s n�zvem "CoroutineParent", pokud je�t� neexistuje.
    /// </summary>
    public class CoroutineMonoBehaviour : MonoBehaviour { }

    /// <summary>
    /// Statick� pomocn� t��da pro spr�vu pojmenovan�ch coroutin.
    /// Umo��uje spou�t�t, p�eru�ovat a sledovat coroutiny ze statick�ho kontextu,
    /// kde nen� p��mo dostupn� MonoBehaviour. Ka�d� coroutina je identifikov�na �et�zcov�m ID.
    /// </summary>
    public static class CoroutineHelper
    {
        /// <summary>
        /// Slovn�k aktivn�ch coroutin mapuj�c� ID na instanci Coroutine.
        /// </summary>
        private static Dictionary<string, Coroutine> coroutines = new Dictionary<string, Coroutine>();

        /// <summary>
        /// Ve�ejn� p��stup ke slovn�ku aktivn�ch coroutin (pouze pro �ten� extern�).
        /// </summary>
        public static Dictionary<string, Coroutine> Coroutines { get { return coroutines; } }

        /// <summary>
        /// MonoBehaviour objekt, na kter�m jsou coroutiny skute�n� spou�t�ny.
        /// </summary>
        private static CoroutineMonoBehaviour coroutineParent;

        /// <summary>
        /// Spust� coroutinu s dan�m ID. Pokud coroutina se stejn�m ID ji� b��, nejprve ji zastav�.
        /// Pokud hostitelsk� objekt neexistuje, vytvo�� ho automaticky.
        /// </summary>
        /// <param name="routine">Metoda coroutiny k spu�t�n�.</param>
        /// <param name="id">Unik�tn� textov� ID coroutiny.</param>
        /// <returns>Reference na spu�t�nou Coroutine.</returns>
        public static Coroutine StartCoroutine(IEnumerator routine, string id)
        {
            if (coroutineParent == null)
            {
                coroutineParent = new GameObject("CoroutineParent").AddComponent<CoroutineMonoBehaviour>();
            }
            if (coroutines.ContainsKey(id))
            {
                StopCoroutine(id);
            }
            var coroutine = coroutineParent.StartCoroutine(routine);
            coroutines.Add(id, coroutine);
            return coroutine;
        }

        /// <summary>
        /// Zastav� coroutinu s dan�m ID a odstran� ji ze slovn�ku.
        /// Pokud coroutina s t�mto ID neexistuje, metoda nic neprovede.
        /// </summary>
        /// <param name="id">ID coroutiny k zastaven�.</param>
        public static void StopCoroutine(string id)
        {
            if (coroutines.ContainsKey(id))
            {
                var coroutine = coroutines[id];
                if (coroutine != null) coroutineParent.StopCoroutine(coroutine);
                coroutines.Remove(id);
            }
        }

        /// <summary>
        /// Zastav� coroutinu podle jej� instance a odstran� ji ze slovn�ku.
        /// Prohled� slovn�k a najde odpov�daj�c� z�znam podle reference.
        /// </summary>
        /// <param name="coroutine">Instance Coroutine k zastaven�.</param>
        public static void StopCoroutine(Coroutine coroutine)
        {
            foreach (var pair in coroutines)
            {
                if (pair.Value == coroutine)
                {
                    coroutines.Remove(pair.Key);
                    coroutineParent.StopCoroutine(coroutine);
                    return;
                }
            }
        }
    }
}